CREATE OR REPLACE FUNCTION get_completed_skills(user_id_param UUID)
RETURNS TABLE (
    id INTEGER,
    title TEXT,
    category TEXT,
    description TEXT,
    completed_at TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        s.id,
        s.title,
        s.category,
        s.description,
        ual.timestamp as completed_at
    FROM 
        skills s
    JOIN 
        user_activity_log ual ON s.id = ual.skill_id
    WHERE 
        ual.user_id = user_id_param
    ORDER BY 
        ual.timestamp DESC;
END;
$$ LANGUAGE plpgsql;