-- Enable email/password authentication
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;

-- Enable Google OAuth
INSERT INTO auth.providers (id)
VALUES ('google')
ON CONFLICT (id) DO NOTHING;