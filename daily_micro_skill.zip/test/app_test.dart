import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:mocktail/mocktail.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:daily_micro_skill/main.dart';
import 'package:daily_micro_skill/screens/splash_screen.dart';
import 'package:daily_micro_skill/screens/onboarding_screen.dart';
import 'package:daily_micro_skill/screens/auth_screen.dart';
import 'package:daily_micro_skill/screens/home_screen.dart';
import 'package:daily_micro_skill/screens/history_screen.dart';

class MockGoRouter extends Mock implements GoRouter {}
class MockSupabaseClient extends Mock implements SupabaseClient {}

void main() {
  late MockGoRouter mockRouter;
  late MockSupabaseClient mockSupabase;

  setUp(() {
    mockRouter = MockGoRouter();
    mockSupabase = MockSupabaseClient();
  });

  group('App Tests', () {
    testWidgets('App starts and shows splash screen', (tester) async {
      await tester.pumpWidget(const MyApp());
      expect(find.byType(SplashScreen), findsOneWidget);
    });
  });

  group('Splash Screen Tests', () {
    testWidgets('Shows logo and app name', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const FlutterLogo(size: 100),
                  const SizedBox(height: 20),
                  Text(
                    'Daily Micro-Skill',
                    style: Theme.of(tester.element(find.byType(Text))).textTheme.headlineMedium,
                  ),
                ],
              ),
            ),
          ),
        ),
      );

      expect(find.byType(FlutterLogo), findsOneWidget);
      expect(find.text('Daily Micro-Skill'), findsOneWidget);
    });
  });

  group('Onboarding Screen Tests', () {
    testWidgets('Shows interest selection', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: const OnboardingScreen(),
        ),
      );

      expect(find.text('Select Your Interests'), findsOneWidget);
      expect(find.byType(FilterChip), findsNWidgets(8));
    });
  });

  group('Auth Screen Tests', () {
    testWidgets('Shows login options', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: const AuthScreen(),
        ),
      );

      expect(find.text('Sign In'), findsOneWidget);
      expect(find.byType(TextField), findsNWidgets(2));
      expect(find.text('Sign In with Google'), findsOneWidget);
    });
  });

  group('Home Screen Tests', () {
    testWidgets('Shows daily skill when available', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: const HomeScreen(),
        ),
      );

      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });
  });

  group('History Screen Tests', () {
    testWidgets('Shows completed skills', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: const HistoryScreen(),
        ),
      );

      expect(find.byType(CircularProgressIndicator), findsOneWidget);
    });
  });
}