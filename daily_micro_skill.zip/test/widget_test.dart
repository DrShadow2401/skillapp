import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:mocktail/mocktail.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MockGoRouter extends Mock implements GoRouter {}
class MockSupabaseClient extends Mock implements SupabaseClient {}

void main() {
  late MockGoRouter mockRouter;
  late MockSupabaseClient mockSupabase;

  setUp(() {
    mockRouter = MockGoRouter();
    mockSupabase = MockSupabaseClient();
  });

  testWidgets('Splash screen renders correctly', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const FlutterLogo(size: 100),
                const SizedBox(height: 20),
                Text(
                  'Daily Micro-Skill',
                  style: Theme.of(tester.element(find.byType(Text))).textTheme.headlineMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );

    expect(find.byType(FlutterLogo), findsOneWidget);
    expect(find.text('Daily Micro-Skill'), findsOneWidget);
  });
}