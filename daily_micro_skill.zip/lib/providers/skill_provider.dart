import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final skillProvider = FutureProvider.autoDispose<Map<String, dynamic>?>((ref) async {
  final supabase = Supabase.instance.client;
  final userId = supabase.auth.currentUser?.id;
  
  if (userId == null) return null;

  // Get user interests
  final interestsRes = await supabase
      .from('interests')
      .select('interests')
      .eq('user_id', userId)
      .single();
  
  final interests = interestsRes['interests'] as List<dynamic>;

  // Get completed skills
  final completedRes = await supabase
      .from('user_activity_log')
      .select('skill_id')
      .eq('user_id', userId);
  
  final completedIds = completedRes.data?.map((e) => e['skill_id']).toList() ?? [];

  // Get matching skills
  final skillsRes = await supabase
      .from('skills')
      .select('*')
      .contains('category', interests)
      .not('id', 'in', completedIds);
  
  if (skillsRes.data?.isNotEmpty ?? false) {
    return skillsRes.data!.first;
  }

  // Fallback to any skill not completed
  final fallbackRes = await supabase
      .from('skills')
      .select('*')
      .not('id', 'in', completedIds);
  
  return fallbackRes.data?.first;
});