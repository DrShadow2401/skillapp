import 'package:firebase_analytics/firebase_analytics.dart';

class AnalyticsService {
  static final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  static Future<void> logEvent(String name, [Map<String, dynamic>? params]) async {
    await _analytics.logEvent(
      name: name,
      parameters: params,
    );
  }

  static Future<void> setUserProperty(String name, String value) async {
    await _analytics.setUserProperty(name: name, value: value);
  }

  static Future<void> setCurrentScreen(String screenName) async {
    await _analytics.setCurrentScreen(
      screenName: screenName,
      screenClassOverride: screenName,
    );
  }
}