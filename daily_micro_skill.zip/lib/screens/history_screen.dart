import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  final _supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _completedSkills = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchCompletedSkills();
  }

  Future<void> _fetchCompletedSkills() async {
    setState(() => _isLoading = true);
    try {
      final userId = _supabase.auth.currentUser?.id;
      if (userId == null) return;

      final response = await _supabase
          .from('user_activity_log')
          .select('''
            *, 
            skills:skill_id(title, category, description)
          ''')
          .eq('user_id', userId)
          .order('timestamp', ascending: false);

      setState(() {
        _completedSkills = (response.data as List).cast<Map<String, dynamic>>();
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error fetching history: ${e.toString()}')),
        );
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Completed Skills'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _completedSkills.isEmpty
              ? const Center(child: Text('No completed skills yet'))
              : ListView.builder(
                  padding: const EdgeInsets.all(16.0),
                  itemCount: _completedSkills.length,
                  itemBuilder: (context, index) {
                    final skill = _completedSkills[index];
                    final skillData = skill['skills'] as Map<String, dynamic>;
                    final timestamp = DateTime.parse(skill['timestamp']);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Chip(
                                  label: Text(skillData['category']),
                                  backgroundColor:
                                      Colors.deepPurple.withOpacity(0.2),
                                ),
                                Text(
                                  DateFormat('MMM d, yyyy').format(timestamp),
                                  style: const TextStyle(color: Colors.grey),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(
                              skillData['title'],
                              style: Theme.of(context).textTheme.titleMedium,
                            ),
                            const SizedBox(height: 8),
                            Text(skillData['description']),
                          ],
                        ),
                      ),
                    );
                  },
                ),
    );
  }
}