import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final selectedInterestsProvider = StateProvider<List<String>>((ref) => []);

class OnboardingScreen extends ConsumerWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selectedInterests = ref.watch(selectedInterestsProvider);
    final interests = [
      'Creativity',
      'Health',
      'Productivity',
      'Social',
      'Focus',
      'Physical',
      'Mindfulness',
      'Learning'
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Your Interests'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'What areas would you like to improve?',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: interests.map((interest) {
                return FilterChip(
                  label: Text(interest),
                  selected: selectedInterests.contains(interest),
                  onSelected: (selected) {
                    ref.read(selectedInterestsProvider.notifier).update((state) {
                      if (selected) {
                        return [...state, interest];
                      } else {
                        return state.where((item) => item != interest).toList();
                      }
                    });
                  },
                );
              }).toList(),
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () => _saveInterests(ref, context),
                child: const Text('Continue'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveInterests(WidgetRef ref, BuildContext context) async {
    final selectedInterests = ref.read(selectedInterestsProvider);
    if (selectedInterests.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select at least one interest')),
      );
      return;
    }

    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    await supabase.from('interests').upsert({
      'user_id': userId,
      'interests': selectedInterests,
    });

    if (context.mounted) {
      context.go('/home');
    }
  }
}