# Daily Micro-Skill Backend

This is the FastAPI backend for the Daily Micro-Skill Generator app.

## Deployment to Render

1. Create a new account on [Render](https://render.com) if you don't have one
2. Click "New +" and select "Web Service"
3. Connect your GitHub repository containing this code
4. Select the repository and branch
5. Configure the service with these settings:
   - Name: `daily-micro-skill-backend`
   - Region: `Oregon (US West)`
   - Branch: `main`
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `uvicorn main:app --host 0.0.0.0 --port 10000`
6. Add these environment variables:
   - `SUPABASE_URL`: Your Supabase project URL
   - `SUPABASE_KEY`: Your Supabase anon/public key
7. Click "Create Web Service" to deploy

## Environment Variables

The following environment variables are required:

- `SUPABASE_URL`: Your Supabase project URL
- `SUPABASE_KEY`: Your Supabase anon/public key