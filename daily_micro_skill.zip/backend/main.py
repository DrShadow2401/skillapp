from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import os
from supabase import create_client, Client
from typing import List, Optional
import random

app = FastAPI()
security = HTTPBearer()

# Initialize Supabase client
supabase_url = os.getenv("SUPABASE_URL")
supabase_key = os.getenv("SUPABASE_KEY")
supabase: Client = create_client(supabase_url, supabase_key)

class SkillSuggestion(BaseModel):
    id: int
    title: str
    category: str
    description: str

class CompleteSkillRequest(BaseModel):
    skill_id: int

@app.get("/suggest", response_model=SkillSuggestion)
async def suggest_skill(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verify JWT token
        user = supabase.auth.get_user(credentials.credentials)
        user_id = user.user.id

        # Get user's interests
        interests_res = supabase.table('interests').select('interests').eq('user_id', user_id).execute()
        interests = interests_res.data[0]['interests'] if interests_res.data else []

        # Get completed skills
        completed_res = supabase.table('user_activity_log').select('skill_id').eq('user_id', user_id).execute()
        completed_ids = [item['skill_id'] for item in completed_res.data] if completed_res.data else []

        # Get matching skills not completed yet
        if interests:
            skills_res = supabase.table('skills').select('*').contains('category', interests).execute()
        else:
            skills_res = supabase.table('skills').select('*').execute()

        available_skills = [skill for skill in skills_res.data if skill['id'] not in completed_ids]

        if not available_skills:
            # Fallback to any skill not completed yet
            skills_res = supabase.table('skills').select('*').execute()
            available_skills = [skill for skill in skills_res.data if skill['id'] not in completed_ids]

        if not available_skills:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No available skills found"
            )

        # Return a random skill from available ones
        return random.choice(available_skills)

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

@app.post("/complete")
async def complete_skill(
    request: CompleteSkillRequest,
    credentials: HTTPAuthorizationCredentials = Depends(security)
):
    try:
        # Verify JWT token
        user = supabase.auth.get_user(credentials.credentials)
        user_id = user.user.id

        # Record completion
        supabase.table('user_activity_log').insert({
            'user_id': user_id,
            'skill_id': request.skill_id
        }).execute()

        return {"message": "Skill marked as completed"}

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )

@app.get("/history", response_model=List[SkillSuggestion])
async def get_history(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        # Verify JWT token
        user = supabase.auth.get_user(credentials.credentials)
        user_id = user.user.id

        # Get completed skills with details
        res = supabase.rpc('get_completed_skills', {
            'user_id_param': user_id
        }).execute()

        return res.data

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials"
        )